import numpy as np
import random

random.seed(7)

def load_dots(path, target_max=9000):
    arr = np.load(path)
    ys, xs = np.nonzero(arr)
    coords = list(zip(xs.tolist(), ys.tolist()))
    if len(coords) > target_max:
        # stratified thin: keep every Nth by shuffling deterministically then slicing evenly spaced indices
        idx = np.linspace(0, len(coords)-1, target_max).astype(int)
        coords = [coords[i] for i in idx]
    return coords

dark = load_dots("dark_dots.npy", target_max=9500)
light = load_dots("light_dots.npy", target_max=9500)
print("dark:", len(dark), "light:", len(light))

import json
json.dump(dark, open("dark_coords.json","w"))
json.dump(light, open("light_coords.json","w"))
