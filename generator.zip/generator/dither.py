import numpy as np
from PIL import Image, ImageOps, ImageFilter
import json

GRID_W, GRID_H = 300, 340
im_small = Image.open("cropped_small.png").convert("RGB")
mask = np.load("mask.npy")  # True = subject

gray = ImageOps.grayscale(im_small)
gray = ImageOps.autocontrast(gray, cutoff=1)
gray = gray.filter(ImageFilter.UnsharpMask(radius=3, percent=140))
g = np.array(gray).astype(np.float32)
g = 128 + (g - 128) * 1.3
g = np.clip(g, 0, 255)

def floyd_steinberg(gray_arr, invert_serpentine=True):
    a = gray_arr.copy()
    h, w = a.shape
    out = np.zeros((h, w), dtype=np.uint8)
    for y in range(h):
        serp = invert_serpentine and (y % 2 == 1)
        xs = range(w-1, -1, -1) if serp else range(w)
        for x in xs:
            old = a[y, x]
            new = 255.0 if old > 127 else 0.0
            out[y, x] = 1 if new == 0 else 0  # 1 = ink dot (dark)
            err = old - new
            nxt = x - 1 if serp else x + 1
            if 0 <= nxt < w:
                a[y, nxt] += err * 7/16
            if y+1 < h:
                if 0 <= x-1 if not serp else x+1 < w:
                    pass
            if y+1 < h and x-1 >= 0:
                a[y+1, x-1] += err * (3/16 if not serp else 1/16)
            if y+1 < h:
                a[y+1, x] += err * 5/16
            if y+1 < h and x+1 < w:
                a[y+1, x+1] += err * (1/16 if not serp else 3/16)
    return out

ink = floyd_steinberg(g)  # 1 where dot should be drawn (dark tone)

# LIGHT MODE: keep background, dots = dark parts of photo (ink==1 everywhere)
light_dots = ink.copy()

# DARK MODE: only draw dots where mask (subject) is true -> "lit subject on panel"
dark_dots = ink * mask.astype(np.uint8)
# hard-clear error-diffusion bleed at mask edge: erode mask by 1px for dot placement
from scipy import ndimage
mask_eroded = ndimage.binary_erosion(mask, iterations=1)
dark_dots = ink * mask_eroded.astype(np.uint8)

print("light dot count:", light_dots.sum())
print("dark dot count:", dark_dots.sum())

np.save("light_dots.npy", light_dots)
np.save("dark_dots.npy", dark_dots)

# quick raster preview
Image.fromarray(((1-light_dots)*255).astype(np.uint8)).save("preview_light.png")
Image.fromarray(((1-dark_dots)*255).astype(np.uint8)).save("preview_dark.png")
