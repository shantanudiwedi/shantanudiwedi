import json, random, math

random.seed(42)

CANVAS_W, CANVAS_H = 1180, 610
GRID_W, GRID_H = 300, 340

def build_svg(theme):
    dark = theme == "dark"
    coords = json.load(open(f"{'dark' if dark else 'light'}_coords.json"))

    # theme palette
    if dark:
        bg = "#0A101F"
        panel_bg = "#0d1424"
        panel_border = "#1e2a45"
        dot_color = "#A78BFA"
        chrome = "#22D3EE"
        accent = "#10B981"
        text = "#94A3B8"
        text_bright = "#F8FAFC"
        label_dim = "#64748B"
        live_red = "#EF4444"
    else:
        bg = "#F8FAFC"
        panel_bg = "#FFFFFF"
        panel_border = "#E2E8F0"
        dot_color = "#7C3AED"
        chrome = "#0891B2"
        accent = "#059669"
        text = "#475569"
        text_bright = "#0F172A"
        label_dim = "#94A3B8"
        live_red = "#DC2626"

    # ---- portrait frame geometry ----
    frame_x, frame_y = 46, 96
    frame_w, frame_h = 380, 428
    s = min(frame_w / GRID_W, frame_h / GRID_H)
    port_w, port_h = GRID_W * s, GRID_H * s
    off_x = frame_x + (frame_w - port_w) / 2
    off_y = frame_y + (frame_h - port_h) / 2
    dotsize = round(s * 0.82, 2)

    def cell_path(cx, cy):
        x = round(off_x + cx * s, 2)
        y = round(off_y + cy * s, 2)
        return f"M{x} {y}h{dotsize}v{dotsize}h-{dotsize}z"

    # shuffle + split into intro groups (scattered spatially by construction)
    idxs = list(range(len(coords)))
    random.shuffle(idxs)
    N_GROUPS = 48
    groups = [idxs[i::N_GROUPS] for i in range(N_GROUPS)]

    # base low-opacity duplicate layer (always visible faint, avoids "pop from nothing")
    base_path_d = "".join(cell_path(*coords[i]) for i in idxs)

    # intro + breathing loop groups
    group_svgs = []
    for gi, grp in enumerate(groups):
        d = "".join(cell_path(*coords[i]) for i in grp)
        delay = round(random.uniform(0, 1.7), 3)
        fade_dur = round(random.uniform(0.5, 1.1), 3)
        # breathing loop: gentle opacity flicker + micro translate, phase offset per group
        phase = round((gi / N_GROUPS) * 14.2, 2)
        bob = round(random.uniform(0.6, 1.4), 2)
        group_svgs.append(f'''<path d="{d}" fill="{dot_color}" opacity="0" shape-rendering="crispEdges">
      <animate attributeName="opacity" values="0;1" dur="{fade_dur}s" begin="{delay}s" fill="freeze"/>
      <animate attributeName="opacity" values="1;0.82;1" dur="{round(6+bob,2)}s" begin="{delay+2}s" repeatCount="indefinite"/>
    </path>
    <g>
      <animateTransform attributeName="transform" type="translate" values="0,0;0,{-bob};0,0" dur="{round(9+bob,2)}s" begin="{phase}s" repeatCount="indefinite"/>
    </g>''')

    portrait_layer = f'''<g clip-path="url(#portraitClip{'D' if dark else 'L'})">
    <path d="{base_path_d}" fill="{dot_color}" opacity="0.05" shape-rendering="crispEdges"/>
    {"".join(group_svgs)}
  </g>'''

    # ---- info panel ----
    info_x = frame_x + frame_w + 44
    rows_top = [
        ("Subject", "Shantanu H. Diwedi"),
        ("Role", "B.Tech CSE Student"),
        ("Origin", "Pune, Maharashtra, IN"),
        ("Education", "MIT ADT University"),
        ("Status", "Learning . Building . Contributing"),
        ("ToolChain", "VS Code . Git . GitHub"),
    ]
    rows_core = [
        ("Core.Lang", "Python . C"),
        ("Core.Frontend", "HTML5 . CSS3"),
        ("Core.Backend", "Learning"),
        ("Core.Database", "SQL (Learning)"),
        ("Core.Infra", "Git . GitHub"),
    ]
    rows_grid = [
        ("Grid.Mail", "shantanudiwedi2007@..."),
        ("Grid.Portfolio", "coming soon"),
        ("Grid.LinkedIn", "/in/shantanu-diwedi"),
        ("Grid.GitHub", "@shantanudiwedi"),
    ]

    def dotted_leader_row(label, value, y):
        label_w = len(label) * 7.1
        value_w = len(value) * 6.6
        leader_x1 = info_x + label_w + 8
        leader_x2 = CANVAS_W - 46 - value_w - 8
        leader = ""
        if leader_x2 > leader_x1:
            leader = f'<line x1="{leader_x1}" y1="{y-4}" x2="{leader_x2}" y2="{y-4}" stroke="{panel_border}" stroke-width="1" stroke-dasharray="1.5,3"/>'
        return f'''<text x="{info_x}" y="{y}" font-family="JetBrains Mono, Consolas, monospace" font-size="13" fill="{label_dim}">{label}</text>
    {leader}
    <text x="{CANVAS_W-46}" y="{y}" text-anchor="end" font-family="JetBrains Mono, Consolas, monospace" font-size="13" fill="{text_bright}" textLength="{value_w}" lengthAdjust="spacingAndGlyphs">{value}</text>'''

    y = 130
    info_rows_svg = []
    for label, val in rows_top:
        info_rows_svg.append(dotted_leader_row(label, val, y)); y += 23
    y += 10
    for label, val in rows_core:
        info_rows_svg.append(dotted_leader_row(label, val, y)); y += 23
    y += 10
    for label, val in rows_grid:
        info_rows_svg.append(dotted_leader_row(label, val, y)); y += 23

    svg = f'''<svg width="{CANVAS_W}" height="{CANVAS_H}" viewBox="0 0 {CANVAS_W} {CANVAS_H}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <clipPath id="portraitClip{'D' if dark else 'L'}">
      <rect x="{frame_x}" y="{frame_y}" width="{frame_w}" height="{frame_h}" rx="6"/>
    </clipPath>
  </defs>
  <rect width="{CANVAS_W}" height="{CANVAS_H}" rx="14" fill="{bg}"/>
  <rect x="1" y="1" width="{CANVAS_W-2}" height="{CANVAS_H-2}" rx="13" fill="none" stroke="{panel_border}" stroke-width="1.5"/>

  <!-- title bar -->
  <rect x="1" y="1" width="{CANVAS_W-2}" height="40" rx="13" fill="{panel_bg}"/>
  <rect x="1" y="28" width="{CANVAS_W-2}" height="14" fill="{panel_bg}"/>
  <circle cx="28" cy="21" r="6" fill="#EF4444" opacity="0.75"/>
  <circle cx="48" cy="21" r="6" fill="#F59E0B" opacity="0.75"/>
  <circle cx="68" cy="21" r="6" fill="#10B981" opacity="0.75"/>
  <text x="{CANVAS_W/2}" y="26" text-anchor="middle" font-family="JetBrains Mono, Consolas, monospace" font-size="13" fill="{text}">profile.sh --live</text>

  <!-- LIVE badge -->
  <circle cx="{CANVAS_W-150}" cy="21" r="4" fill="{live_red}">
    <animate attributeName="opacity" values="1;0.25;1" dur="1.4s" repeatCount="indefinite"/>
  </circle>
  <text x="{CANVAS_W-140}" y="25" font-family="JetBrains Mono, Consolas, monospace" font-size="12" fill="{live_red}">LIVE</text>
  <rect x="{CANVAS_W-96}" y="10" width="70" height="22" rx="11" fill="{accent}" opacity="0.15" stroke="{accent}" stroke-width="1"/>
  <text x="{CANVAS_W-61}" y="25" text-anchor="middle" font-family="JetBrains Mono, Consolas, monospace" font-size="14" fill="{accent}">@shantanu</text>

  <!-- portrait frame -->
  <text x="{frame_x}" y="82" font-family="JetBrains Mono, Consolas, monospace" font-size="13" letter-spacing="2" fill="{chrome}">VISUAL.MAP</text>
  <rect x="{frame_x}" y="{frame_y}" width="{frame_w}" height="{frame_h}" rx="6" fill="{panel_bg}" stroke="{panel_border}" stroke-width="1.5"/>
  {portrait_layer}

  <!-- info panel -->
  <text x="{info_x}" y="82" font-family="JetBrains Mono, Consolas, monospace" font-size="13" letter-spacing="2" fill="{chrome}">SYSTEM.INFO</text>
  {"".join(info_rows_svg)}
</svg>'''
    return svg

dark_svg = build_svg("dark")
light_svg = build_svg("light")
open("dark.svg", "w").write(dark_svg)
open("light.svg", "w").write(light_svg)
print("dark bytes:", len(dark_svg.encode()))
print("light bytes:", len(light_svg.encode()))
