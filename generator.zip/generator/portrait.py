import numpy as np
from PIL import Image, ImageOps, ImageFilter
from scipy import ndimage

SRC = "/mnt/user-data/uploads/1000133426.webp"
GRID_W, GRID_H = 300, 340

im = Image.open(SRC).convert("RGB")
w, h = im.size

# Crop to head+shoulders, target aspect GRID_W:GRID_H (300:340 ~ 0.882)
target_ratio = GRID_W / GRID_H
cur_ratio = w / h
if cur_ratio > target_ratio:
    new_w = int(h * target_ratio)
    x0 = (w - new_w) // 2
    im = im.crop((x0, 0, x0 + new_w, h))
else:
    new_h = int(w / target_ratio)
    y0 = 0  # keep top (head), crop from bottom
    im = im.crop((0, y0, w, y0 + new_h))

# slight crop-in from top to reduce headroom, and shift down a touch (head+shoulders not tight face)
w2, h2 = im.size
top_trim = int(h2 * 0.03)
im = im.crop((0, top_trim, w2, h2))

im_full = im.copy()
im_small = im.resize((GRID_W, GRID_H), Image.LANCZOS)

# ---- Background segmentation for dark-mode mask ----
arr = np.array(im_small).astype(np.float32)
# sample background color from corners
corners = np.concatenate([
    arr[0:15, 0:15].reshape(-1,3),
    arr[0:15, -15:].reshape(-1,3),
    arr[-15:, 0:15].reshape(-1,3),
    arr[-15:, -15:].reshape(-1,3),
])
bg_color = np.median(corners, axis=0)
dist = np.linalg.norm(arr - bg_color, axis=2)
thresh = np.percentile(dist, 35)  # adaptive
mask = dist > (thresh * 1.15)

# clean mask: binary closing + fill holes + keep largest component
mask = ndimage.binary_closing(mask, structure=np.ones((5,5)))
mask = ndimage.binary_fill_holes(mask)
labeled, n = ndimage.label(mask)
if n > 0:
    sizes = ndimage.sum(mask, labeled, range(1, n+1))
    largest = np.argmax(sizes) + 1
    mask = labeled == largest
mask = ndimage.binary_dilation(mask, iterations=1)

print("bg_color", bg_color, "subject px:", mask.sum(), "/", mask.size)

Image.fromarray((mask*255).astype(np.uint8)).save("mask_preview.png")
im_small.save("cropped_small.png")
im_full.save("cropped_full.png")
np.save("mask.npy", mask)
im_small.save("small_for_dither.png")
